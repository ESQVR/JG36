// class FollowBehavior {
//   constructor(target = null) {
//     this.target = target;
//   }
//   setTarget(target) {
//     this.target = target;
//   }
//   update() {
//     if (this.target) {
//       console.log('Following ' + this.target);
//     }

//   }
// }