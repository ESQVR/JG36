

Notes:
    - WARNING: space won't be read by cli if game.js ran in same context
    - For now audio may overlap; audio  play in superposition when too much incantations validated in time shorter than audio feedback time
    - For now only US no latin model found
    